<!doctype html>
<html class="no-js" lang="">

<?php
    require DOCROOT."/includes/head.inc.php";
?>

<body>
    <?php
        require DOCROOT."/includes/header.inc.php";
        require DOCROOT."/classes/Produit.class.php";
    
        $Produit = new Produit();
        $Produit->id = "7";
        $Produit->Find();
        echo $Produit->nom."</br>";
        echo "<img src='img/".$Produit->image.".jpg' alt='Couverture' width='260' height='400'></br>";
        echo $Produit->description."</br>";
        echo "Date de publication: ".$Produit->date."</br>";
        echo "Prix: ".$Produit->prix."$</br>";
        echo "Quantité en stock: ".$Produit->quantite."</br></br>";

        require DOCROOT."/includes/footer.inc.php";
        require DOCROOT."/includes/javascript.inc.php";
    ?>
</body>

</html>