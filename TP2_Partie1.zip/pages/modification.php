<!doctype html>
<html class="no-js" lang="">

<?php
    require DOCROOT."/includes/head.inc.php";
?>

<body>
    <?php
        require DOCROOT."/includes/header.inc.php";
    ?>
    <p>Modification</p>
    <form action="/action/validateModification.php" method="post">
        <div class="rendered-form">
            <div class="formbuilder-text form-group field-firstName">
                <label for="firstName" class="formbuilder-text-label">Prénom
                </label>
                <input type="text" name="firstName" id="firstName">
            </div>
            <div class="formbuilder-text form-group field-lastName">
                <label for="lastName" class="formbuilder-text-label">Nom
                </label>
                <input type="text" name="lastName" id="lastName">
            </div>
            <div class="formbuilder-text form-group field-adress">
                <label for="adress" class="formbuilder-text-label">Adresse
                </label>
                <input type="text" name="adress" id="adress">
            </div>
            <div class="formbuilder-text form-group field-city">
                <label for="city" class="formbuilder-text-label">Ville
                </label>
                <input type="text" name="city" id="city">
            </div>
            <div class="formbuilder-text form-group field-province">
                <label for="province" class="formbuilder-text-label">Province
                </label>
                <input type="text" name="province" id="province">
            </div>
            <div class="formbuilder-text form-group field-postalCode">
                <label for="postalCode" class="formbuilder-text-label">Code Postal
                </label>
                <input type="text" name="postalCode" id="postalCode" pattern="[A-Za-z][0-9][A-Za-z][0-9][A-Za-z][0-9]">
            </div>
            <div class="form-group col-sm-12 col-md-6 col-lg-4">
                <label for="password">Mot de passe<span style="color: red;">*</span></label>
                <input type="password" class="form-control" name="password" id="password" pattern=".{8,}"
                    title="8 caractères ou plus." />
                <div class="invalid-tooltip">
                    Veuillez entrez un mot de passe de plus de 8 caractères.
                </div>
            </div>
            <div class="form-group col-sm-12 col-md-6 col-lg-4">
                <label for="password-confirm">Confirmer le mot de passe<span style="color: red;">*</span></label>
                <input type="password" class="form-control" name="passwordConfirm" id="passwordConfirm" />
                <div class="invalid-tooltip" id="passwordConfirmation-message">
                    Veuillez confirmer votre mot de passe.
                </div>
            </div>
            <div class="form-group col-sm-12 col-md-6 col-lg-4">
                <label for="email">Votre courriel<span style="color: red;">*</span></label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroupPrepend2">@</span>
                    </div>
                    <input type="email" class="form-control" name="email" id="email" />
                    <div class="invalid-tooltip">
                        Veuillez ajouter votre adresse email.
                    </div>
                </div>
            </div>
            <input type="submit" value="Modifier">
        </div>
    </form>

    <?php
        require DOCROOT."/includes/footer.inc.php";
        require DOCROOT."/includes/javascript.inc.php";
    ?>
</body>

</html>