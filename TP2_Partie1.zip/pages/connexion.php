<!doctype html>
<html class="no-js" lang="">

<?php
    require DOCROOT."/includes/head.inc.php";
?>

<body>
    <?php
        require DOCROOT."/includes/header.inc.php";
    ?>

    <?php
        if (isset($_SESSION['utilisateur'])):
            echo "Déjà connecté";
        else: ?>
    <p>Connexion</p>
    <form method="post" action="action/validateConnection.php">
        <div class="rendered-form">
            <div class="formbuilder-text form-group field-user">
                <label for="user" class="formbuilder-text-label">Nom d'usager
                    <span class="formbuilder-required">*</span>
                </label></br>
                <input type="text" name="user" id="user" required="required"></div>
            <div class="form-group col-sm-12 col-md-6 col-lg-4">
                <label for="password">Mot de passe<span style="color: red;">*</span></label>
                <input type="password" class="form-control" name="password" id="password" required="required"
                    pattern=".{8,}" title="8 caractères ou plus." />
                <div class="invalid-tooltip">
                    Veuillez entrez un mot de passe de plus de 8 caractères.
                </div>
            </div>
        </div>
        <div>
            <input type="submit" value="Se connecter">
        </div>
    </form>
    <?php endif; ?>

    <?php
        require DOCROOT."/includes/footer.inc.php";
        require DOCROOT."/includes/javascript.inc.php";
    ?>
</body>

</html>