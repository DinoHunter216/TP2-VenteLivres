<!doctype html>
<html class="no-js" lang="">

<?php
    require DOCROOT."/includes/head.inc.php";
?>

<body>
    <?php
        require DOCROOT."/includes/header.inc.php";
    ?>

    <p>Modele</p>

    <?php
        require DOCROOT."/includes/footer.inc.php";
        require DOCROOT."/includes/javascript.inc.php";
    ?>
</body>

</html>