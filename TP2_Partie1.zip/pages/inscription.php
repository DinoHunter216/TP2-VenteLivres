<!doctype html>
<html class="no-js" lang="">

<?php
    require DOCROOT."/includes/head.inc.php";
?>

<body>
    <?php
        require DOCROOT."/includes/header.inc.php";
    ?>

    <?php
        if (isset($_SESSION['utilisateur'])):
            echo "Déjà connecté";
        else: ?>
    <p>Inscription</p>
    <form action="/action/validateInscription.php" method="post">
        <div class="rendered-form">
            <div class="formbuilder-text form-group field-firstName">
                <label for="firstName" class="formbuilder-text-label">Prénom
                    <span class="formbuilder-required">*</span>
                </label>
                <input type="text" name="firstName" id="firstName" required="required">
            </div>
            <div class="formbuilder-text form-group field-lastName">
                <label for="lastName" class="formbuilder-text-label">Nom
                    <span class="formbuilder-required">*</span>
                </label>
                <input type="text" name="lastName" id="lastName" required="required">
            </div>
            <div class="formbuilder-text form-group field-adress">
                <label for="adress" class="formbuilder-text-label">Adresse
                    <span class="formbuilder-required">*</span>
                </label>
                <input type="text" name="adress" id="adress" required="required">
            </div>
            <div class="formbuilder-text form-group field-city">
                <label for="city" class="formbuilder-text-label">Ville
                    <span class="formbuilder-required">*</span>
                </label>
                <input type="text" name="city" id="city" required="required">
            </div>
            <div class="formbuilder-text form-group field-province">
                <label for="province" class="formbuilder-text-label">Province
                    <span class="formbuilder-required">*</span>
                </label>
                <input type="text" name="province" id="province" required="required">
            </div>
            <div class="formbuilder-text form-group field-postalCode">
                <label for="postalCode" class="formbuilder-text-label">Code Postal
                    <span class="formbuilder-required">*</span>
                </label>
                <input type="text" name="postalCode" id="postalCode" required="required"
                    pattern="[A-Za-z][0-9][A-Za-z][0-9][A-Za-z][0-9]">
            </div>
            <div class="formbuilder-text form-group field-user">
                <label for="user" class="formbuilder-text-label">Nom
                    d'usager
                    <span class="formbuilder-required">*</span>
                </label>
                <input type="text" name="user" id="user" required="required">
            </div>
            <div class="form-group col-sm-12 col-md-6 col-lg-4">
                <label for="password">Mot de passe<span style="color: red;">*</span></label>
                <input type="password" class="form-control" name="password" id="password" required="required"
                    pattern=".{8,}" title="8 caractères ou plus." />
                <div class="invalid-tooltip">
                    Veuillez entrez un mot de passe de plus de 8 caractères.
                </div>
            </div>
            <div class="form-group col-sm-12 col-md-6 col-lg-4">
                <label for="password-confirm">Confirmer le mot de passe<span style="color: red;">*</span></label>
                <input type="password" class="form-control" name="passwordConfirm" id="passwordConfirm"
                    required="required" />
                <div class="invalid-tooltip" id="passwordConfirmation-message">
                    Veuillez confirmer votre mot de passe.
                </div>
            </div>
            <div class="form-group col-sm-12 col-md-6 col-lg-4">
                <label for="email">Votre courriel<span style="color: red;">*</span></label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroupPrepend2">@</span>
                    </div>
                    <input type="email" class="form-control" name="email" id="email" required="required" />
                    <div class="invalid-tooltip">
                        Veuillez ajouter votre adresse email.
                    </div>
                </div>
            </div>
            <input type="submit" value="M'inscrire">
        </div>
    </form>
    <?php endif; ?>

    <?php
        require DOCROOT."/includes/footer.inc.php";
        require DOCROOT."/includes/javascript.inc.php";
    ?>
</body>

</html>