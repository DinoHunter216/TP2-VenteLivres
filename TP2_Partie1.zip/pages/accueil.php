<!doctype html>
<html class="no-js" lang="">

<?php
    require DOCROOT."/includes/head.inc.php";
?>

<body>
    <?php
        require DOCROOT."/includes/header.inc.php";
        require DOCROOT."/classes/Produit.class.php";
    ?>

    <p>Accueil - Le côté visuel viendra sous peu</p>

    <?php
    
    $Produit = new Produit();
    $produits = $Produit->all();

    foreach ($produits as $produit) {
        echo $produit['nom']."</br>";
        echo "<img src='img/".$produit['image'].".jpg' alt='Couverture' width='130' height='200'></br>";
        echo "<a href='".$produit['image']."'>Voir plus</a></br>";
    }
    
    ?>

    <?php
        require DOCROOT."/includes/footer.inc.php";
        require DOCROOT."/includes/javascript.inc.php";
    ?>
</body>

</html>