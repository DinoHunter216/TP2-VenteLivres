<header>
    <h1>eCommerce - Livres</h1>
    <?php
        session_start();
        if (isset($_SESSION['utilisateur'])):
        echo "Utilisateur: ".$_SESSION['utilisateur']."</br>";
        echo "<a href='/deconnexion'>Se déconnecter</a></br>";
        echo "<a href='/modification'>Modifier mon profil</a></br>";
        else:
        echo "<a href='/connexion'>Se connecter</a></br>";
        echo "<a href='/inscription'>S'inscrire</a>";
        endif; ?>

    <form action="/action/validateSearch.php" method="post">
        <div class="rendered-form">
            <div class="formbuilder-text form-group field-search">
                <input type="text" name="search" id="search" required="required">
            </div>
            <div>
                <input type="submit" value="Rechercher">
            </div>
        </div>
    </form>
    <a href="/accueil">Accueil</a>
    </br>
</header>