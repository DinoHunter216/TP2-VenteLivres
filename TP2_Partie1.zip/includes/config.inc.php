<?php
    define("SITEURL", $_SERVER["HTTP_HOST"]);
    define("SITESTATE", "dev"); //prod ou dev

    define("SITETITLE", "TP2");
    define("SITEDESC", "");
    define("SITEOWNER", "Jeremy Dumas");

    ///section pour ma bd
    define("DBNAME", "ecommerce");
    define("DBUSERNAME", "webphp");
    define("DBPASSWORD", "qwerty123");

    define('DOCROOT', $_SERVER['DOCUMENT_ROOT']);
