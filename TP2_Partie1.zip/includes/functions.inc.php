<?php

    function redirect($url = "/")
    {
        header("Location:".$url);
        die();
    }

    function createSession($user)
    {
        session_start();

        $_SESSION['utilisateur'] = $user;
    }

    function checkForUser($user)
    {
        $Client = new Client();
        $clients = $Client->all();

        foreach ($clients as $client) {
            if ($client['usager'] === $user) {
                return $client['id'];
            }
        }
        return -1;
    }

    // Encryption à venir si temps
    function checkForPassword($password, $id)
    {
        $Client = new Client();
        $Client->id = $id;
        $Client->Find();

        if ($Client->mot_passe === $password) {
            return true;
        }
        return false;
    }

    function checkForEmail($email, $id)
    {
        $Client = new Client();
        $Client->id = $id;
        $Client->Find();

        if ($Client->courriel === $email) {
            return true;
        }
        return false;
    }


    function productExist($search)
    {
        $Produit = new Produit();
        $produits = $Produit->all();

        $id = array();

        foreach ($produits as $produit) {
            if (strpos($produit['nom'], $search) !== false) {
                array_push($id, $produit['id']);
            }
        }
        return $id;
    }

    function showProduct($id)
    {
        $Produit = new Produit();
        for ($i = 0; $i < sizeof($id); $i++) {
            $Produit->id = $id[$i];
            $Produit->Find();
            echo $Produit->nom."</br>";
            echo "<img src='/img/".$Produit->image.".jpg' alt='Couverture' width='130' height='200'></br>";
            echo "<a href='/index.php?page=".$Produit->image."'>Voir plus</a></br>";
        }
    }
